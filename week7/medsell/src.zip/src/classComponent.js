import { Component } from "react";

class ClassComponent extends Component{
    render(){
        return(
            <div>
                <h1>Class Component</h1>
            </div>
        )
    }
}

export default ClassComponent;