import React from 'react'

const AboutComponent = () => {
  return (
    <div>AboutComponent</div>
  )
}

export default AboutComponent;