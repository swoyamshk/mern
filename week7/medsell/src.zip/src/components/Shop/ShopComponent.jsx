import React from 'react'

const ShopComponent = () => {
  return (
    <div>ShopComponent</div>
  )
}

export default ShopComponent