import React from 'react'

//Child Component
const PropsPrac = props => {
  return (
    <div>Hello {props.name} {props.surname}</div>
  )
}

export default PropsPrac