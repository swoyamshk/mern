import React from 'react'
import GreetComponent from './greetComponent'

const GreetS = () => {
  return (
    <GreetComponent name="Jon"/>
  )
}

export default GreetS