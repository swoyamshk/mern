import React from 'react'
import GreetComponent from './greetComponent'

const GreetD = () => {
  return (
    <GreetComponent name="Doe"/>
  )
}

export default GreetD